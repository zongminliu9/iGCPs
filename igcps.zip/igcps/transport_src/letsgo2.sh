#!/bin/bash
#SBATCH --mem=300G  # 请求 10GB 内存
#SBATCH --job-name=letsgo2
#SBATCH --ntasks=28
#SBATCH --time=24:00:00   # 最大运行时间
#SBATCH --partition=bigmem
#SBATCH --output=/scratch/groups/yyanmin/zongmingnew4/letsgo21.sh
#SBATCH --error=/scratch/groups/yyanmin/zongmingnew4/letsgo21.sh

# 加载所需模块
module load openmpi/4.1.2
module load petsc/3.18.5


# 运行程序

mpiexec -np 28 ./transport /scratch/groups/yyanmin/zongmingnew/ 28

